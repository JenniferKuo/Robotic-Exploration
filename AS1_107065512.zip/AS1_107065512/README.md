# 執行方法
``` 
cd AS1_107065512
python main.py
```